<?php
	if(!isset($login)){exit();}
?>
	<a href="?menu=them_sp">Thêm phim</a><br>
	<a href="?menu=ql_sanpham">Quản lý phim</a>
