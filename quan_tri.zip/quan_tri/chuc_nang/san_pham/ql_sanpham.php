<div class="container-fluid">
    <h1 class="mt-4">Danh sách phim</h1>
    <div class="card mb-4">  
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr class="text-center">
                            <th>Tên phim</th>
                            <th>Loại phim</th>
                            <th>Xem chi tiết</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            include('../connect.php');
                            $loaip= "select * from san_pham";
                            $exec= mysqli_query($connect, $loaip);
                            while($row= mysqli_fetch_array($exec)){
                        ?>
                                <tr>
                                    <td><?php echo $row['tenp']; ?></td>
                                    <td>
                                        <?php  
                                            $loaip= $row['loaip'];
                                            switch ($loaip) {
                                                case 'bo':
                                                    echo "Phim bộ";
                                                    break;
                                                case 'lẻ':
                                                    echo "Phim lẻ";
                                                    break;
                                                case 'kinhdi':
                                                    echo "Phim kinh dị";
                                                    break;
                                                case 'hai':
                                                    echo "Phim hài";
                                                    break;
                                                case 'khoahocvientuong':
                                                    echo "Phim khoa học viến tưởng";
                                                    break;
                                                case 'hanhdong':
                                                    echo "Phim hành động";
                                                    break;
                                                case 'lichsu':
                                                    echo "Phim lịch sử";
                                                    break;                      
                                            }
                                        ?>                                       
                                    </td>
                                    <td>
                                        <a class="btn btn-primary" style="text-decoration: none; padding: 5px 15px; background-color: #1D388F; color: #fffafa;"  href="?menu=chi_tiet&map=<?php echo $row['map']; ?>">Chi tiết</a>
                                    </td>   
                                </tr>
                        <?php  
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>