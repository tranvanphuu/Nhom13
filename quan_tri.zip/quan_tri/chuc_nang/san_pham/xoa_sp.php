<?php
	if(!isset($login)){exit();}
?>
<?php
	include('../connect.php');
	$map= $_GET['map'];
	$sl="delete  from thongtinsp where map=".$map;
	$exec= mysqli_query($connect, $sl);
	if($exec){
		$sl2="delete from san_pham where map=".$map;
		$rs = mysqli_query($connect,$sl2);
		if($rs){
			echo "<script> alert('Xóa phim thành công'); location.href='?menu=ql_sanpham'; </script>";		
		}
	}
	else{
		echo "<script> alert('Xóa phim không thành công'); location.href='?menu=ql_sanpham'; </script>";
	}
?>