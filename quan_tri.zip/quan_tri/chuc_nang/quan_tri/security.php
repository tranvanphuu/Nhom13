<?php 
	if(isset($_SESSION['user']) and isset($_SESSION['pass'])){
		$login= "login";
	}
?>