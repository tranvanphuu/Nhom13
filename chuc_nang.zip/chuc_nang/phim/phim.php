<style type="text/css">
	.content .sp .title a {
    font-size: 15px;
    margin: 25px;
}
	.content .sp {
    height: 330px;
    }
    .btn-default{
    	margin-top: 10px;
    }
    
</style>

<div class="panel panel-warning" style="margin-top: 1em;">
    <div class="panel-heading">Phim nổi bật</div>
    <div class="panel-body">
		<div class="product">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="product">
			<?php
				include('connect.php');
				$sl = 'select * from san_pham where noi_bat="co" limit 0,4';
				$exec = mysqli_query($connect, $sl);
				while($row= mysqli_fetch_array($exec)){
			?>
					<div class="sp img-thumbnail col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="img img-thumbnail col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><img src="images/<?php echo $row['img']; ?>" alt=""></a>
						</div>
						<div class="title">
							<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><?php echo $row['tenp']; ?></a>
						</div>
						
						<div >
							<a class="btn btn-info" href="?menu=product_info&map=<?php echo $row['map']; ?>">Chi tiết</a>
							<a class="btn btn-warning" hre f="?menu=addcart&map=<?php echo $row['map']; ?>&soluong=1">Xem Phim</b></a>
						</div>
					</div>
			<?php 
				}
				$sl2 = 'select * from san_pham where noi_bat="co" ';
				$exec2 = mysqli_query($connect, $sl2);
				if(mysqli_num_rows($exec2) > 4) {
			?>	
				<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<a href="?menu=noi_bat" class="text-center btn btn-default">Xem thêm</a>
				</div>
			<?php
				}
			?>
			</div>
		</div>
	</div>
</div>

<div class="panel panel-warning">
    <div class="panel-heading">Phim xem nhiều</div>
    <div class="panel-body">
		<div class="product">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="product">
			<?php
				include('connect.php');
				$sl= 'select * from san_pham where xem_nhieu > "10" ORDER BY xem_nhieu DESC limit 0,4';
				$exec= mysqli_query($connect, $sl);
				while($row= mysqli_fetch_array($exec)){
			?>
					<div class="sp img-thumbnail col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="img img-thumbnail col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><img src="images/<?php echo $row['img']; ?>" alt=""></a>
						</div>
						<div class="title">
							<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><?php echo $row['tenp']; ?></a>
						</div>
						
						<div>
							<a class="btn btn-info" href="?menu=product_info&map=<?php echo $row['map']; ?>">Chi tiết</a>
							<a class="btn btn-warning" hre f="?menu=addcart&map=<?php echo $row['map']; ?>&soluong=1">Xem Phim</b></a>
						</div>
					</div>
			<?php 
				}
				if(mysqli_num_rows($exec2) > 4) {
			?>	
				<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<a href="?menu=xem_nhieu" class="text-center btn btn-default">Xem thêm</a>
				</div>
			<?php
				}
			?>
			</div>
		</div>
	</div>
</div>

<div class="panel panel-warning">
    <div class="panel-heading">Phim mới</div>
    <div class="panel-body">
		<div class="product">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="product">
			<?php
				include('connect.php');
				$sl= 'select * from san_pham ORDER BY map DESC limit 0,4';
				$exec= mysqli_query($connect, $sl);
				while($row= mysqli_fetch_array($exec)){
			?>
					<div class="sp img-thumbnail col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="img img-thumbnail col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><img src="images/<?php echo $row['img']; ?>" alt=""></a>
						</div>
						<div class="title">
							<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><?php echo $row['tenp']; ?></a>
						</div>
					
						<div>
							<a class="btn btn-info" href="?menu=product_info&map=<?php echo $row['map']; ?>">Chi tiết</a>
							<a class="btn btn-warning" href="?menu=addcart&map=<?php echo $row['map']; ?>&soluong=1">Xem Phim</b></a>
						</div>
					</div>
			<?php 
				}
			?>
				<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<a href="?menu=phim_moi" class="text-center btn btn-default">Xem thêm</a>
				</div>
			</div>
		</div>
	</div>
</div>