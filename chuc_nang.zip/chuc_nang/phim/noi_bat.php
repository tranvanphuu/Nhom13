<div class="panel panel-warning"  style="margin-left: -32px; margin-right: -16px;">
    <div class="panel-heading">Nổi bật</div>
    <div class="panel-body">
		<?php
			include('connect.php');
			$sl= "select * from san_pham where noi_bat='co' limit 0,4"; 
			$exec= mysqli_query($connect, $sl); 
			while($row= mysqli_fetch_array($exec)){
		?>
		<div style="height: 240px;" class="sp img-thumbnail">
		<div class="img img-thumbnail">
			<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><img src="images/<?php echo $row['img']; ?>" alt=""></a>
		</div>
		<div class="title">
			<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><?php echo $row['tenp']; ?></a>
		</div>
	
	</div>
		<?php } ?>
	</div>
</div>