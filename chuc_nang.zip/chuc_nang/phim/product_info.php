<div class="product-info">
<?php
	include ('connect.php');
	$sl   = 'select * from san_pham join thongtinsp on san_pham.map= thongtinsp.map where san_pham.map=' . $_GET['map'];
	$exec = mysqli_query($connect, $sl);
	$row  = mysqli_fetch_array($exec);
?>	
	<div class="panel panel-warning">
    	<div class="panel-heading">
    		<span style="font-weight: bold; color: "><?php echo $row['tenp']; ?></span>
		</div>
    	<div class="panel-body">
			<form method="GET">
				<div class="img-sp col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<script>
						function img1(){
							document.getElementById('img').src="images/<?php echo $row['img']; ?>";
						}
						function img2(){
							document.getElementById('img').src="images/<?php echo $row['img1']; ?>";
						}
						function img3(){
							document.getElementById('img').src="images/<?php echo $row['img2']; ?>";
						}
						function img4(){
							document.getElementById('img').src="images/<?php echo $row['img3']; ?>";
						}						
					</script>
					<img id="img" class="img-thumbnail" src="images/<?php echo $row['img']; ?>">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div style="margin-left: -10px; padding-top: 10px;">
							<img class="img-thumbnail" src="images/<?php echo $row['img']; ?>" style="width: 50px; height: 50px;" onclick="img1();" alt="">
							<img class="img-thumbnail" src="images/<?php echo $row['img1']; ?>" style="width: 50px; height: 50px;" onclick="img2();" alt="">
							<img class="img-thumbnail" src="images/<?php echo $row['img2']; ?>" style="width: 50px; height: 50px;" onclick="img3();" alt="">
							<img class="img-thumbnail" src="images/<?php echo $row['img3']; ?>" style="width: 50px; height: 50px;" onclick="img4();" alt="">				
						</div>
					</div>
				</div>
				
			</form>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding-top: 10px;">
			<ul class="nav nav-pills">
				<li class="active">
					<br><a data-toggle="pill" href="#thong_tin">Mô tả</a><br>
				</li>		
			</ul>	
			<div class="tab-content">
				<div id="thong_tin" class="tab-pane fade in  active">
					<table class="table">
						<tr>				
							<td><?php echo $row['mota1']; ?></td>
						</tr>
						<tr>					
							<td><?php echo $row['mota2']; ?></td>
						</tr>
						<tr>					
							<td><?php echo $row['mota3']; ?></td>
						</tr>
						<tr>						
							<td><?php echo $row['mota4']; ?></td>
						</tr>
						<tr>
							<td><?php echo $row['mota5']; ?></td>
						</tr>
					</table>
				</div>			
			</div>
		</div>	
	</div>
</div>
</div>