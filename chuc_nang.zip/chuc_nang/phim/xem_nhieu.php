<div class="panel panel-warning" style="width: 186px; margin-left: -16px;">
    <div class="panel-heading">Xem nhiều</div>
    <div class="panel-body">
		<?php
			include('connect.php');
			$sl= "select * from san_pham where xem_nhieu > '10' order by xem_nhieu desc limit 0,6"; 
			$exec= mysqli_query($connect, $sl); 
			while($row= mysqli_fetch_array($exec)){
		?>
		<div class="sp img-thumbnail">
		<div class="img img-thumbnail">
			<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><img src="images/<?php echo $row['img']; ?>" alt=""></a>
		</div>
		<div class="title">
			<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><?php echo $row['tenp']; ?></a>
		</div>
	</div>
		<?php } ?>
	</div>
</div>