<div class="panel panel-warning">
    <div class="panel-heading">Phim mới</div>
    <div class="panel-body">
		<div class="product">
		<?php
			include('connect.php');
			if(isset($_GET['page'])){
				$page=$_GET['page'];
			}else{
				$page=1;
			}
			$start=1;
			$page=$page-1;
			$limit= 8;
			$sql="select * from san_pham ORDER BY map DESC limit 0,8";
			$ex= mysqli_query($connect, $sql);
			$total= mysqli_num_rows($ex);
			$total=$total/$limit;
			$total= ceil($total);
			$start= $limit*$page;
		?>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="product">
				<?php
					$sl= "select * from san_pham ORDER BY map DESC limit 0,8 ";
					$exec= mysqli_query($connect, $sl);
					while($row= mysqli_fetch_array($exec)){
				?>
				<div class="sp img-thumbnail col-xs-12 col-sm-8 col-md-4 col-lg-3">
					<div class="img img-thumbnail col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><img src="images/<?php echo $row['img']; ?>" alt=""></a>
					</div>
					<div class="title">
						<a href="?menu=product_info&map=<?php echo $row['map']; ?>"><?php echo $row['tenp']; ?></a>
					</div>
				
					<div>
						<a class="btn btn-info" href="?menu=product_info&map=<?php echo $row['map']; ?>">Chi tiết</a>
						<a class="btn btn-warning" href="?menu=addcart&map=<?php echo $row['map']; ?>&soluong=1">Xem Phim</b></a>
					</div>
				</div>
				<?php 
					}
				?>
			</div>
			<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<nav>
					<ul class="pagination">
						<?php 
						    if($page==0){
						    	if($total>1){ 
						    		$page=$page+2;
						    		$prev="";
						    		$next= '<a href="?menu=phim_moi&page='.$page.'"aria-label="Next"><span class="fa fa-step-forward"></span></a>';		      		
						    	}else{
						    		$prev="";
						    		$next="";
						    	} 
						    }else if($page>=1){
						    	if($page==$total-1){
						    		$prpage= $page;
						    		$firstpage='<a href="?menu=phim_moi&page=1" aria-label="First"><span class="fa fa-fast-backward"></span></a>';
						    		$endpage="";
						    		$prev='<a href="?menu=phim_moi&page='.$prpage.'" aria-label="Next"><span class="fa fa-step-backward"></span></a>';
						    		$page=$page-2;
						    		$next= "";
						    	}else{
						    		$prpage=$page;
						    		$page=$page+2;
						    		$prev= '<a href="?menu=phim_moi&page='.$prpage.'" aria-label="Next"><span class="fa fa-step-backward"></span></a>';
						    		$next='<a href="?menu=phim_moi&page='.$page.'" aria-label="Next"><span class="fa fa-step-forward"></span></a>';			      		
						    	}}
						?>			    
						<li><?php echo $prev; ?></li>
						<?php 	
							if($total>1)    
							for($i=1; $i<=$total; $i++){
						?>
						<li><a href="?menu=phim_moi&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
						<?php
							}	
						?>
						<li><?php echo $next; ?></li>	    
					</ul>
				</nav>			
			</div>
		</div>
	</div>
</div>