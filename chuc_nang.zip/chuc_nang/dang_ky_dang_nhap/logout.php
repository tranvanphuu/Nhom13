<?php
	unset($_SESSION['login']);
	echo "<script> location.href='index.php'; </script>";
?>