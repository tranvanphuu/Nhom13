<div class="panel panel-basic" style="width: 186px; margin-left: -16px;">
    <div class="panel-heading" id="dang_nhap" style="cursor: pointer; " >
      	<span>Đăng nhập</span>
    </div>
    <div id="dang-nhap-form" >
		<form action="?menu=exec_dang_nhap" method="post">
			<table>
				<tr>
					<td>
						<label for="user">Email: </label><br><input type="text" class="form-control"  name="email" id="user" placeholder="Nhập email.." required >
					</td>
				</tr>
				<tr>
					<td>
						<label for="pass">Mật khẩu: </label><br><input type="password" class="form-control"  name="password" id="pass" placeholder="Nhập mật khẩu.." required >
					</td>
				</tr>
				<tr>
					<td colspan="2" style="padding-top: 8px;"><input type="submit" class="btn btn-primary" name="submit" value="Đăng nhập"></td>
				</tr>
			</table>
		</form>
	</div>
</div>

<div class="panel panel-basic" style="width: 186px; margin-left: -16px;">
    <div class="panel-heading" id="dang_ky" style="cursor: pointer; " >
      	<span>Đăng ký</span>
	</div>
</div>