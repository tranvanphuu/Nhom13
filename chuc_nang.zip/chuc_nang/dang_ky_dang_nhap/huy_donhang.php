<?php
	if(!isset($_SESSION['login'])){exit();}
	$connect->begin_transaction();
	$mahd=$_GET['ma_hoadon'];
	$map = $_GET['map'];
	$soluong = $_GET['soluong'];
	$sl='update hoa_don set tinh_trang="Hủy" where mahd='.$_GET['ma_hoadon'];
	$sl2="UPDATE san_pham SET soluong=(soluong + '".$soluong."') WHERE map='".$map."'";
	$exec= mysqli_query($connect, $sl);
	$exec2 = mysqli_query($connect, $sl2);
	if($exec){
		if($exec2){
			echo "<script> alert('Hủy đơn vé thành công');location.href='?menu=chitiet_lichsu&ma_hoadon=$mahd';  </script>";
			$connect->commit();
		}else{
			echo "<script> alert('Hệ thống đang bận. Vui lòng thử lại sau');location.href='?menu=chitiet_lichsu&ma_hoadon=$mahd'; </script>";
			$connect->rollback();
		}
	}else{
		echo "<script> alert('Hệ thống đang bận. Vui lòng thử lại sau');location.href='?menu=chitiet_lichsu&ma_hoadon=$mahd'; </script>";
		$connect->rollback();
	}
?>